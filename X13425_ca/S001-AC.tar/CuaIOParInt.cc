#include "CuaIOParInt.hh"
#include <iostream>
#include <queue>
using namespace std;

void llegirCuaParInt(queue<ParInt>& c){
    ParInt aux;
   while(aux.llegir()){
       c.push(aux);
   }
}

void escriureCuaParInt(queue<ParInt> c){
    while(not c.empty()){
        c.front().escriure();
        c.pop();

    }
}

