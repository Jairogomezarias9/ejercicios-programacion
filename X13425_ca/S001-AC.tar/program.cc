#include "CuaIOParInt.hh"
#include <iostream>
#include <queue>
using namespace std;


queue<ParInt> comprova(queue<ParInt>& q){
    queue<ParInt> aux1;
    queue<ParInt> aux2;
    int it1=0;
    int it2=0;
    while(not q.empty()){
        if(it1<=it2){
            aux1.push(q.front());
            it1+=q.front().segon();

        }
        else{
            aux2.push(q.front());
            it2+=q.front().segon();
        }
        q.pop();
    }
    q=aux1;

    return aux2;
}



int main(){
    queue <ParInt> q;
    queue <ParInt> q2;
    llegirCuaParInt(q);
    q2=comprova(q);
    escriureCuaParInt(q);
    cout<<endl;
    escriureCuaParInt(q2);
}