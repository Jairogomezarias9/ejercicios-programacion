#include "LlistaIOParInt.hh"
#include "ParInt.hh"

void LlegirLlistaParInt(list<ParInt>& l){
    list<ParInt>:: const_iterator it=l.begin();
    ParInt p;
    while(p.llegir()){
        l.insert(it,p);
        
    }
}


