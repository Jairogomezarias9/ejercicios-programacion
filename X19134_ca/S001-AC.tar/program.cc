#include "LlistaIOParInt.hh"


void fer(list<ParInt>& l, int n ){
    list<ParInt>:: const_iterator it=l.begin();
    int suma=0;
    int suma2=0;

    for(it=l.begin(); it!=l.end();++it){
        if((*it).primer()==n){
            suma=suma+1;
            suma2=suma2+(*it).segon();
        }


    }

    cout<<n<<" "<<suma<<" "<<suma2<<endl;

}



int main(){
    list<ParInt> l;
    LlegirLlistaParInt(l);
    int n;
    cin>>n;
    fer(l,n);

}
